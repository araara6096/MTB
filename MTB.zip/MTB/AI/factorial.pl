fact(0,1).
fact(N,X):-N1 is N-1,fact(N1,Y),X is Y*N.
/*
The fact/2 predicate has two clauses:

The base case clause fact(0, 1) states that the factorial of 0 is 1.

The recursive case clause fact(N, X) calculates the factorial of N by recursively calculating the factorial of N-1 and
 multiplying it by N. This is achieved by using the is/2 operator to evaluate the expression Y*N and assign the result
  to X, where Y is the factorial of N-1, calculated by recursively calling the fact/2 predicate with N-1.

The recursive case continues to call fact/2 with a smaller argument until it reaches the base case, at which point it
 can start unwinding and computing the factorial of each number in turn, using the recursive call results to build up
the final result.
*/
read_num(N):-write('Enter the number: '),read(N).

factorial:-
    read_num(N),
    fact(N,X),
    write('Factorial of given number: '),
    write(X).
