gcd(X,Y,D):- X=:=Y,D is X.
gcd(X,Y,D):-
    X>Y,
    X1=X-Y,
    gcd(X1,Y,D).
gcd(X,Y,D):-
    Y>X,
    gcd(Y,X,D).
/*
The gcd/3 predicate has three clauses:

The first clause gcd(X, Y, D) :- X =:= Y, D is X. handles the base case where X and Y are equal. In this case, the GCD
 is X itself, so the D variable is unified with X.

The second clause gcd(X, Y, D) :- X > Y, X1 is X - Y, gcd(X1, Y, D). handles the case where X is greater than Y. In this
 case, the GCD of X and Y is the same as the GCD of X - Y and Y. Therefore, the gcd/3 predicate is called recursively
with X1 (which is X - Y) and Y.

The third clause gcd(X, Y, D) :- Y > X, gcd(Y, X, D). handles the case where Y is greater than X. In this case, the GCD
 of X and Y is the same as the GCD of Y and X. Therefore, the gcd/3 predicate is called recursively with Y and X.

The program uses the is/2 predicate to evaluate arithmetic expressions. For example, in the second clause, X1 is X - Y
 computes the value of X - Y and assigns it to the variable X1.

Overall, the gcd/3 predicate works by recursively calling itself with smaller and smaller values of X and Y until X and
 Y are equal (in the base case). At this point, the GCD is known and is returned as the value of the D variable.
*/

read_num(N):-write('Enter the number: '),read(N).
gcd_program:-
    read_num(N1),
    read_num(N2),
    gcd(N1,N2,R),
    write('The gcd of given number: '),
    write(R).
