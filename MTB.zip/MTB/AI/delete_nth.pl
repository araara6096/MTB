delete_nth(1, [_|T], T).
delete_nth(N, [H|T], [H|R]):-
    N > 1,
    N1 is N - 1,
    delete_nth(N1, T, R).

/*
The delete_nth/3 predicate has two recursive clauses:

The base case clause delete_nth(1, [_|T], T) matches a list with at least one element, removes the first element
 (which is the second element of the original list), and returns the tail of the list as the new list. This is because
  in Prolog, the underscore character _ is used to indicate that a variable is anonymous and its value is not used.

The recursive clause delete_nth(N, [H|T], [H|R]) matches a list with at least two elements, where N is greater than 1.
 In this case, the head H of the list is preserved, and the delete_nth/3 predicate is called recursively with N
  decremented by 1, and the tail of the original list T. The result of this recursive call is assigned to the variable
  R. Finally, the head H is prepended to the result R to produce the final list.

  Overall, the delete_nth/3 predicate works by recursively traversing the list until the Nth element is found. Once the
   Nth element is found, it is removed from the list by either returning the tail of the list (in the base case) or by
    preserving the head and recursively deleting the Nth element from the tail of the list (in the recursive case).
*/
read_list(L):-write('Enter the list: '),read(L).
pos(N):-write('Enter the position of element to be deleted: '),read(N).
delete_n:-
    read_list(L),
    pos(N),
    delete_nth(N,L,R),
    write('The Result after deletion: '),
    write(R).
