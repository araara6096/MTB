% Defining basic functions

read_num(Prompt, N) :-
    write(Prompt),
    read(N).

% Q16. Insert to nth position
insert(_, _, [], []).
insert(X, 0, L, [X | L]).

insert(X, N, [H | T1] , [H | T]) :-
    N1 is N - 1,
    insert(X, N1, T1, T).

insertToList :-
    read_num("Enter the list: ", L),
    read_num("Enter the new value: ", X),
    read_num("Enter the position: ", N),
    insert(X, N, L, R),
    write("The new list: "),
    write(R).

% Q17. Delete at nth position
delete([], _, []).
delete([_ | L], 0, L).

delete([H | T1], N, [H | T]) :-
    N1 is N-1,
    delete(T1, N1, T).

deleteFromList :-
    read_num("Enter the list: ", L),
    read_num("Enter the position: ", N),
    delete(L, N, R),
    write("The new list: "),
    write(R).

% Q18. Merge two lists
merge([], L, L).
merge(L, [], L).

merge([H1 | T1], [H2 | T2], [H | T]) :-
    H1 < H2 ->  
    (   
    	H is H1,
        merge(T1, [H2 | T2], T)
    );
    (   
    	H is H2,
        merge([H1 | T1], T2, T)
    ).

mergeLists :-
    read_num("Enter the list A: ", A),
    read_num("Enter the list B: ", B),
    merge(A, B, M),
    write("The new list: "),
    write(M).
