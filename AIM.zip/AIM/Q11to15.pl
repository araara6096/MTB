% Defining basic functions

read_num(Prompt, N) :-
    write(Prompt),
    read(N).

% Q11. Check if list is palindrome
isPalin([]).
isPalin([_]).

isPalin(L) :-
    append([First | Middle], [Last], L),
    First == Last,
    isPalin(Middle).

isPalindrome :-
    read_num("Enter the list: ", L),
    write("Is the list palindrome? "),
    isPalin(L).

% Q12. Sum List
sumList([], 0).
sumList([X], X).

sumList([X | T], S) :-
    sumList(T, S1),
    S is S1 + X.

sumOfList :-
    read_num("Enter the list: ", L),
    sumList(L, S),
    write("The sum of the list is: "),
    write(S).

% Q13. Even length or Odd length
evenLength(L) :-
    length(L, Len),
    Len mod 2 =:= 0.

oddLength(L) :-
    length(L, Len),
    Len mod 2 =:= 1.

isEvenLength :-
    read_num("Enter the list: ", L),
    write("Does the list have an even length? "),
    evenLength(L).

isOddLength :-
    read_num("Enter the list: ", L),
    write("Does the list have an odd length? "),
    oddLength(L).

% Q14. Nth element of the list
nth_element([], _, -1).
nth_element([X | _], 0, X).

nth_element([_ | T], N, X) :-
    N1 is N - 1,
    nth_element(T, N1, X).

nthElement :-
    read_num("Enter the list: ", L),
    read_num("Enter the N: ", N),
    nth_element(L, N, X),
    write("The Nth element is: "),
    write(X).

% Q15. Maximum of list
maxList([], -1).
maxList([X], X).

maxList([X | T], M) :-
    maxList(T, M1),
    (   
    	X > M1 ->  M is X ;
    	M is M1
    ).

maximumOfList :-
    read_num("Enter the list: ", L),
    maxList(L, M),
    write("The maximum of the list is: "),
    write(M).

