% Defining basic functions

read_num(Prompt, N) :-
    write(Prompt),
    read(N).

% Q1. Sum
sum(N1, N2, Sum) :- Sum is N1 + N2.

sumOfTwoNums :-
    read_num("Enter the first number: ", N1),
    read_num("Enter the second number: ", N2),
    sum(N1, N2, Sum),
    write("The sum is: "),
    write(Sum).

% Q2. Max of two nums
max(X, Y, M) :-
    (   X >= Y,
        M is X
    );
    M is Y.

maxOfTwoNums :-
    read_num("Enter the first number: ", N1),
    read_num("Enter the second number: ", N2),
    max(N1, N2, M),
    write("The max is: "),
    write(M).

% Q3. Factorial
fact(0, 1).

fact(X, Fact) :-
    X1 is X - 1,
    fact(X1, Prev),
    Fact is X * Prev.

factorial :-
    read_num("Enter the number: ", X),
    fact(X, Fact),
    write("The factorial is: "),
    write(Fact).

% Q4. Generate Fibonacci
fibo(1, 1).
fibo(2, 1).

fibo(N, X) :-
    N1 is N-1,
    N2 is N-2,
    fibo(N1, X1),
    fibo(N2, X2),
    X is X1 + X2.

fibonacci :-
    read_num("Enter the value of N: ", N),
    fibo(N, X),
    write("The nth term is: "),
    write(X).

% Q5. GCD of two numbers
gcd(X, X, X).

gcd(X, Y, D) :-
    X > Y,
    Y1 is X-Y,
    gcd(Y, Y1, D).

gcd(X, Y, D) :-
    Y > X,
    gcd(Y, X, D).

gcdOfTwoNums :-
    read_num("Enter the first number: ", N1),
    read_num("Enter the second number: ", N2),
    gcd(N1, N2, D),
    write("The GCD is: "),
    write(D).