% Defining basic functions

read_num(Prompt, N) :-
    write(Prompt),
    read(N).

% Q6. Power
pow(_, 0, 1).

pow(X, Y, R) :-
    Y1 is Y - 1,
    pow(X, Y1, R1),
    R is X * R1.

power :-
    read_num("Enter the number: ", X),
    read_num("Enter the power: ", Y),
    pow(X, Y, Ans),
    write("The exponential is: "),
    write(Ans).

% Q7. Multiplication
multi(X, Y, Ans) :- Ans is X * Y.

multiplication :-
    read_num("Enter the first number: ", N1),
    read_num("Enter the second number: ", N2),
    multi(N1, N2, Ans),
    write("The product is: "),
    write(Ans).

% Q8. Member of list
isMember(X, [X | _]).

isMember(X, [_ | Tail]) :-
    isMember(X, Tail).

isMemberOfList :-
    read_num("Enter the list: ", L),
    read_num("Enter the number: ", N),
    isMember(N, L).


% Q9. Concatenate two lists
concat([], L, L).

concat([X | T1], L2, [X | T]) :-
    concat(T1, L2, T).

concatenateTwoLists :-
    read_num("Enter the first list: ", L1),
    read_num("Enter the second list: ", L2),
    concat(L1, L2, L),
    write("The concatenated list is: "),
    write(L).

% Q10. Reverse a list
reverse([], []).
reverse([X], [X]).

reverse([X | T], R) :-
    reverse(T, R1),
    append(R1, [X], R).

reverseList :-
    read_num("Enter the first list: ", L),
    reverse(L,R),
    write("The reverse is: "),
    write(R).
