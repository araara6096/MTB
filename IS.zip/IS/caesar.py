secret = str(input("Enter the secret to encrypt: "))

step = int(input("Enter the step: "))

letters = [chr(x) for x in range(97, 123)]

encrypted = []

for letter in secret:
    if letter.isalpha():
        idx = ord(letter) - 97
        encrypted.append(letters[(idx + step) % 26])
    else:
        encrypted.append(letter)

encrypted = "".join(encrypted)

print("Encrypted: " + encrypted)